# projects
these are the R Markdown codes I wrote for my senior thesis project. I will update this in the future with new code
